## script to check files and run student program on provided sample test cases
# This script is available to students.
cd RoboGrader
python3 robochecker.py StackRecursion ~/workspace
cd ..
